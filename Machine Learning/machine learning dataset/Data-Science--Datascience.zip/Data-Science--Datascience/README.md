# Data-Science
This is the Data Science Repository .
,In this i will be going to write all the codes from starting from Python.
python libraries ( Numpy, Pandas, scikit learn),
data visualization ( matplotlib and seaborn)
,Machine learning ( data encoding, algorithm ( KNN,SVM,Decision tree,Logistic Regression, Linear Regression)
    ,feature Enginerring as well.
,EDA( data cleanising ,data mining, and many more things using our pandas )

we are going to start with Machine learning and as the time passes all the things will get posted
This will be the only repository on my profile

You are going to learn a lot from this repository a lot.

